package dangNhap_dangKy;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;

import chinhSuaThongTin.ChinhSuaThongTin;
import database.TaiKhoanDatabase;
import giaoDienChinh.GiaoDienChinh;
import taiKhoan.TaiKhoan;

import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;

public class DangNhap {

	TaiKhoanDatabase taiKhoanDatabase;
	
	public JFrame frame;
	private JTextField tenTaiKhoan_tf;
	private JPasswordField matKhau_pf;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DangNhap window = new DangNhap();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public DangNhap() {
		taiKhoanDatabase = new TaiKhoanDatabase();
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBackground(Color.LIGHT_GRAY);
		frame.setBounds(400, 150, 668, 487);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		setUpLabels();
		setUpTextFields();
		setUpButtons();
		setUpBackground();
	}
	
	void setUpLabels() {
		
		JLabel lblDangnhap = new JLabel("Dang Nhap");
		lblDangnhap.setForeground(Color.BLUE);
		lblDangnhap.setHorizontalAlignment(SwingConstants.CENTER);
		lblDangnhap.setFont(new Font("Times New Roman", Font.PLAIN, 36));
		lblDangnhap.setBounds(226, 75, 195, 51);
		frame.getContentPane().add(lblDangnhap);
		
		JLabel lblTaiKhoan = new JLabel("Tai khoan");
		lblTaiKhoan.setForeground(Color.BLUE);
		lblTaiKhoan.setBackground(Color.WHITE);
		lblTaiKhoan.setHorizontalAlignment(SwingConstants.CENTER);
		lblTaiKhoan.setFont(new Font("Times New Roman", Font.PLAIN, 24));
		lblTaiKhoan.setBounds(135, 173, 111, 33);
		frame.getContentPane().add(lblTaiKhoan);
		
		JLabel lblMatKhau = new JLabel("Mat khau");
		lblMatKhau.setForeground(Color.BLUE);
		lblMatKhau.setFont(new Font("Times New Roman", Font.PLAIN, 24));
		lblMatKhau.setHorizontalAlignment(SwingConstants.CENTER);
		lblMatKhau.setBounds(135, 238, 111, 34);
		frame.getContentPane().add(lblMatKhau);
		
		JLabel lblQuenMatKhau = new JLabel("Quen mat khau???");
		lblQuenMatKhau.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblQuenMatKhau.setHorizontalAlignment(SwingConstants.CENTER);
		lblQuenMatKhau.setBounds(145, 344, 137, 31);
		frame.getContentPane().add(lblQuenMatKhau);
	}
	
	void setUpBackground() {
		JLabel lblhnDangNhap = new JLabel("");
		String iconFolderPath = ChinhSuaThongTin.iconFolderPath;
		lblhnDangNhap.setIcon(new ImageIcon(iconFolderPath+"dang_nhap.png"));
		lblhnDangNhap.setBounds(0, 0, 656, 453);
		frame.getContentPane().add(lblhnDangNhap);
	}

	void setUpTextFields() {
		tenTaiKhoan_tf = new JTextField();
		tenTaiKhoan_tf.setForeground(SystemColor.desktop);
		tenTaiKhoan_tf.setFont(new Font("Times New Roman", Font.PLAIN, 24));
		tenTaiKhoan_tf.setHorizontalAlignment(SwingConstants.CENTER);
		tenTaiKhoan_tf.setBounds(305, 174, 213, 30);
		frame.getContentPane().add(tenTaiKhoan_tf);
		tenTaiKhoan_tf.setColumns(10);
		
		matKhau_pf = new JPasswordField();
		matKhau_pf.setForeground(SystemColor.desktop);
		matKhau_pf.setFont(new Font("Times New Roman", Font.PLAIN, 24));
		matKhau_pf.setHorizontalAlignment(SwingConstants.CENTER);
		matKhau_pf.setBounds(305, 239, 213, 31);
		frame.getContentPane().add(matKhau_pf);
	}
	
	void setUpButtons() {
		JButton btnDangNhap = new JButton("Dang nhap");
		btnDangNhap.setForeground(SystemColor.desktop);
		btnDangNhap.setBackground(SystemColor.control);
		btnDangNhap.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		btnDangNhap.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dangNhapBtnPressed();
			}
		});
		btnDangNhap.setBounds(145, 310, 137, 33);
		frame.getContentPane().add(btnDangNhap);
		
		JButton btnHuy = new JButton("Huy");
		btnHuy.setForeground(SystemColor.desktop);
		btnHuy.setBackground(SystemColor.control);
		btnHuy.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		btnHuy.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				huyBtnPressed();
			}
		});
		btnHuy.setBounds(397, 310, 121, 33);
		frame.getContentPane().add(btnHuy);
	}
	
	void dangNhapBtnPressed() {
		try {
			dangNhap();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	void dangNhap() throws Exception {
		String tenTaiKhoanNhapVao = tenTaiKhoan_tf.getText();
		String matKhauNhapVao = matKhau_pf.getText();
		if(tenTaiKhoanNhapVao.isEmpty() || matKhauNhapVao.isEmpty() || !matKhauNhapVao.equals(taiKhoanDatabase.getMatKhau(tenTaiKhoanNhapVao))) {
			JOptionPane.showMessageDialog(null, "Bạn đã nhập sai Tài Khoản hoặc Mật Khẩu!", "Error", JOptionPane.ERROR_MESSAGE);
		} else {
			TaiKhoan taiKhoan = taiKhoanDatabase.getTaiKhoan(tenTaiKhoanNhapVao);
			GiaoDienChinh window = new GiaoDienChinh(taiKhoan);
			window.frame.setVisible(true);
			frame.dispose();
		}
	}
	
	void huyBtnPressed() {
		frame.dispose();
	}
}
