package dangNhap_dangKy;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;

import chinhSuaThongTin.ChinhSuaThongTin;

import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.SystemColor;
import javax.swing.ImageIcon;

public class DangNhap {

	private JFrame frame;
	private JTextField textField;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DangNhap window = new DangNhap();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public DangNhap() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBackground(Color.LIGHT_GRAY);
		frame.setBounds(400, 150, 668, 487);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblDangnhap = new JLabel("Dang Nhap");
		lblDangnhap.setForeground(Color.BLUE);
		lblDangnhap.setHorizontalAlignment(SwingConstants.CENTER);
		lblDangnhap.setFont(new Font("Times New Roman", Font.PLAIN, 36));
		lblDangnhap.setBounds(226, 75, 195, 51);
		frame.getContentPane().add(lblDangnhap);
		
		JLabel lblTaiKhoan = new JLabel("Tai khoan");
		lblTaiKhoan.setForeground(Color.BLUE);
		lblTaiKhoan.setBackground(Color.WHITE);
		lblTaiKhoan.setHorizontalAlignment(SwingConstants.CENTER);
		lblTaiKhoan.setFont(new Font("Times New Roman", Font.PLAIN, 24));
		lblTaiKhoan.setBounds(135, 173, 111, 33);
		frame.getContentPane().add(lblTaiKhoan);
		
		JLabel lblMatKhau = new JLabel("Mat khau");
		lblMatKhau.setForeground(Color.BLUE);
		lblMatKhau.setFont(new Font("Times New Roman", Font.PLAIN, 24));
		lblMatKhau.setHorizontalAlignment(SwingConstants.CENTER);
		lblMatKhau.setBounds(135, 238, 111, 34);
		frame.getContentPane().add(lblMatKhau);
		
		textField = new JTextField();
		textField.setForeground(SystemColor.desktop);
		textField.setFont(new Font("Times New Roman", Font.PLAIN, 24));
		textField.setHorizontalAlignment(SwingConstants.CENTER);
		textField.setBounds(305, 174, 213, 30);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setForeground(SystemColor.desktop);
		passwordField.setFont(new Font("Times New Roman", Font.PLAIN, 24));
		passwordField.setHorizontalAlignment(SwingConstants.CENTER);
		passwordField.setBounds(305, 239, 213, 31);
		frame.getContentPane().add(passwordField);
		
		JButton btnDangNhap = new JButton("Dang nhap");
		btnDangNhap.setForeground(SystemColor.desktop);
		btnDangNhap.setBackground(SystemColor.control);
		btnDangNhap.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		btnDangNhap.setBounds(145, 310, 137, 33);
		frame.getContentPane().add(btnDangNhap);
		
		JButton btnHuy = new JButton("Huy");
		btnHuy.setForeground(SystemColor.desktop);
		btnHuy.setBackground(SystemColor.control);
		btnHuy.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		btnHuy.setBounds(397, 310, 121, 33);
		frame.getContentPane().add(btnHuy);
		
		JLabel lblQuenMatKhau = new JLabel("Quen mat khau???");
		lblQuenMatKhau.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblQuenMatKhau.setHorizontalAlignment(SwingConstants.CENTER);
		lblQuenMatKhau.setBounds(145, 344, 137, 31);
		frame.getContentPane().add(lblQuenMatKhau);
		
		JLabel lblhnDangNhap = new JLabel("");
		String iconFolderPath = ChinhSuaThongTin.iconFolderPath;
		lblhnDangNhap.setIcon(new ImageIcon(iconFolderPath+"dang_nhap.png"));
		lblhnDangNhap.setBounds(0, 0, 656, 453);
		frame.getContentPane().add(lblhnDangNhap);
	}
}
