package taiKhoan;

public class TaiKhoan {
	String taiKhoan;
	String matKhau;
	String hoTen;
	String namSinh;
	String dienThoai;
	
	public TaiKhoan(String taiKhoan, String matKhau, String hoTen, String namSinh, String dienThoai) {
		this.taiKhoan = taiKhoan;
		this.matKhau = matKhau;
		this.hoTen = hoTen;
		this.namSinh = namSinh;
		this.dienThoai = dienThoai;
	}
	
	public String getTaiKhoan() {
		return taiKhoan;
	}
	
	public String getMatKhau() {
		return matKhau;
	}
	
	public String getHoTen() {
		return hoTen;
	}
	
	public String getNamSinh() {
		return namSinh;
	}
	
	public String getDienThoai() {
		return dienThoai;
	}
}
