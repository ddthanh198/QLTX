package giaoDienChinh;

import java.awt.EventQueue;

import javax.swing.*;
import java.awt.Font;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import javax.swing.border.EtchedBorder;
import javax.swing.table.DefaultTableModel;

import chinhSuaThongTin.ChinhSuaThongTin;
import thongBao.ChonMotHang;
import database.*;
import khachHang.*;
import nhanVien.*;
import thueXe.*;
import xe.*;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class GiaoDienChinh {
	
	GiaoDienChinh giaoDienChinh = this;
	
	Database database;
	XeDatabase xeDatabase;
	KhachHangDatabase khachHangDatabase;
	NhanVienDatabase nhanVienDatabase;
	ThueXeDatabase thueXeDatabase;
	
	JFrame frame;
	JPanel xePnl;
	JPanel khachHangPnl;
	JPanel nhanVienPnl;
	JPanel thueXePnl;
	JPanel taiKhoanPnl;
	
	public JTable xeTable = new JTable();
	public JTable khachHangTable = new JTable();
	public JTable nhanVienTable = new JTable();
	public JTable thueXeTable = new JTable();
	
	String iconFolderPath = ChinhSuaThongTin.iconFolderPath;
	ImageIcon themIcon = new ImageIcon(iconFolderPath + "them.png");
	ImageIcon suaIcon = new ImageIcon(iconFolderPath + "sua.png");
	ImageIcon xoaIcon = new ImageIcon(iconFolderPath + "xoa.png");
	ImageIcon nhapFileIcon = new ImageIcon(iconFolderPath + "nhapFile.png");
	ImageIcon timKiemIcon = new ImageIcon(iconFolderPath + "timKiem.png");
	ImageIcon thongKeIcon = new ImageIcon(iconFolderPath + "thongKe.png");
	ImageIcon inPhieuIcon = new ImageIcon(iconFolderPath + "inPhieu.png");
	ImageIcon tienIcon = new ImageIcon(iconFolderPath + "tien.png");
	ImageIcon chiTietIcon = new ImageIcon(iconFolderPath + "chiTiet.png");
	ImageIcon xeIcon = new ImageIcon(iconFolderPath + "xe.png");
	ImageIcon khachHangIcon = new ImageIcon(iconFolderPath + "khachHang.png");
	ImageIcon nhanVienIcon = new ImageIcon(iconFolderPath + "nhanVien.png");
	ImageIcon thueXeIcon = new ImageIcon(iconFolderPath + "thueXe.png");
	ImageIcon taiKhoanIcon = new ImageIcon(iconFolderPath + "taiKhoan.png");
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GiaoDienChinh window = new GiaoDienChinh();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public GiaoDienChinh() throws Exception {
		database = new Database();
		xeDatabase = new XeDatabase();
		khachHangDatabase = new KhachHangDatabase();
		nhanVienDatabase = new NhanVienDatabase();
		thueXeDatabase = new ThueXeDatabase();
		
		xeDatabase.connection = database.connection;
		khachHangDatabase.connection = database.connection;
		nhanVienDatabase.connection = database.connection;
		thueXeDatabase.connection = database.connection;
		
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() throws Exception {
		frame = new JFrame();
		frame.setTitle("QUAN LY THUE XE");
		frame.setBounds(30, 30, 1300, 700);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		tabbedPane.setFont(new Font("Avenir Next", Font.BOLD, 24));
		tabbedPane.setBounds(6, 6, 1288, 666);
		frame.getContentPane().add(tabbedPane);
		
		xePnl = new JPanel();
		tabbedPane.addTab("Xe", xeIcon, xePnl, null);
		xePnl.setLayout(null);
		setUpPanel(xePnl, "Xe", xeTable);
		
		khachHangPnl = new JPanel();
		tabbedPane.addTab("Khach Hang", khachHangIcon, khachHangPnl, null);
		khachHangPnl.setLayout(null);
		setUpPanel(khachHangPnl, "KhachHang", khachHangTable);
		
		nhanVienPnl = new JPanel();
		tabbedPane.addTab("Nhan Vien", nhanVienIcon, nhanVienPnl, null);
		nhanVienPnl.setLayout(null);
		setUpPanel(nhanVienPnl, "NhanVien", nhanVienTable);
		
		thueXePnl = new JPanel();
		tabbedPane.addTab("Thue Xe", thueXeIcon, thueXePnl, null);
		thueXePnl.setLayout(null);
		setUpThueXePanel();
		
		taiKhoanPnl = new JPanel();
		tabbedPane.addTab("Tai Khoan", taiKhoanIcon, taiKhoanPnl, null);
		taiKhoanPnl.setLayout(null);
		setUpTaiKhoanPanel();
	}
	
	void setUpPanel(JPanel panel, String databaseTable, JTable table) throws Exception {
		updateTable(databaseTable, table);
		table.setFont(new Font("Lucida Grande", Font.PLAIN, 17));
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(6, 6, 1251, 412);
		panel.add(scrollPane);
		scrollPane.setViewportView(table);
		
		JButton themBtn = new JButton("Them", themIcon);
		themBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(panel == xePnl) {
					ThemXe window = new ThemXe(giaoDienChinh);
					window.frame.setVisible(true);
				} else if(panel == khachHangPnl) {
					ThemKhachHang window = new ThemKhachHang(giaoDienChinh);
					window.frame.setVisible(true);
				} else if(panel == nhanVienPnl) {
					ThemNhanVien window = new ThemNhanVien(giaoDienChinh);
					window.frame.setVisible(true);
				} 
			}
		});
		themBtn.setHorizontalTextPosition(JButton.CENTER);
		themBtn.setVerticalTextPosition(JButton.BOTTOM);
		themBtn.setFont(new Font("Avenir Next", Font.BOLD, 24));
		themBtn.setBounds(28, 445, 150, 156);
		panel.add(themBtn);
		
		JButton suaBtn = new JButton("Sua", suaIcon);
		suaBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(panel == xePnl) {
					int row = xeTable.getSelectedRow();
					if (row < 0) {
						ChonMotHang window = new ChonMotHang();
						window.frame.setVisible(true);
					} else {
						String maXeCanSua = (String) xeTable.getValueAt(row, 0);
						SuaXe window = new SuaXe(giaoDienChinh, maXeCanSua);
						window.frame.setVisible(true);
					}
				} else if(panel == khachHangPnl) {
					int row = khachHangTable.getSelectedRow();
					if (row < 0) {
						ChonMotHang window = new ChonMotHang();
						window.frame.setVisible(true);
					} else {
						String maKhachHangCanSua = (String) khachHangTable.getValueAt(row, 0);
						SuaKhachHang window = new SuaKhachHang(giaoDienChinh, maKhachHangCanSua);
						window.frame.setVisible(true);
					}
				} else if(panel == nhanVienPnl) {
					int row = nhanVienTable.getSelectedRow();
					if (row < 0) {
						ChonMotHang window = new ChonMotHang();
						window.frame.setVisible(true);
					} else {
						String maNhanVienCanSua = (String) nhanVienTable.getValueAt(row, 0);
						SuaNhanVien window = new SuaNhanVien(giaoDienChinh, maNhanVienCanSua);
						window.frame.setVisible(true);
					}
				} 
			}
		});
		suaBtn.setVerticalTextPosition(SwingConstants.BOTTOM);
		suaBtn.setHorizontalTextPosition(SwingConstants.CENTER);
		suaBtn.setFont(new Font("Avenir Next", Font.BOLD, 24));
		suaBtn.setBounds(238, 445, 150, 156);
		panel.add(suaBtn);
		
		JButton xoaBtn = new JButton("Xoa", xoaIcon);
		xoaBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(panel == xePnl) {
					int row = xeTable.getSelectedRow();
					if (row < 0) {
						ChonMotHang window = new ChonMotHang();
						window.frame.setVisible(true);
					} else {
						String maXeCanXoa = (String) xeTable.getValueAt(row, 0);
						XoaXe window = new XoaXe(giaoDienChinh, maXeCanXoa);
						window.frame.setVisible(true);
					}
				} else if(panel == khachHangPnl) {
					int row = khachHangTable.getSelectedRow();
					if (row < 0) {
						ChonMotHang window = new ChonMotHang();
						window.frame.setVisible(true);
					} else {
						String maKhachHangCanXoa = (String) khachHangTable.getValueAt(row, 0);
						XoaKhachHang window = new XoaKhachHang(giaoDienChinh, maKhachHangCanXoa);
						window.frame.setVisible(true);
					}
				} else if(panel == nhanVienPnl) {
					int row = nhanVienTable.getSelectedRow();
					if (row < 0) {
						ChonMotHang window = new ChonMotHang();
						window.frame.setVisible(true);
					} else {
						String maNhanVienCanXoa = (String) nhanVienTable.getValueAt(row, 0);
						XoaNhanVien window = new XoaNhanVien(giaoDienChinh, maNhanVienCanXoa);
						window.frame.setVisible(true);
					}
				} 
			}
		});
		xoaBtn.setVerticalTextPosition(SwingConstants.BOTTOM);
		xoaBtn.setHorizontalTextPosition(SwingConstants.CENTER);
		xoaBtn.setFont(new Font("Avenir Next", Font.BOLD, 24));
		xoaBtn.setBounds(448, 445, 150, 156);
		panel.add(xoaBtn);
		
		JButton timKiemBtn = new JButton("Tim Kiem", timKiemIcon);
		timKiemBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(panel == xePnl) {
					
				} else if(panel == khachHangPnl) {

				} else if(panel == nhanVienPnl) {
					
				} else {
					
				}
			}
		});
		timKiemBtn.setVerticalTextPosition(SwingConstants.BOTTOM);
		timKiemBtn.setHorizontalTextPosition(SwingConstants.CENTER);
		timKiemBtn.setFont(new Font("Avenir Next", Font.BOLD, 24));
		timKiemBtn.setBounds(658, 445, 150, 156);
		panel.add(timKiemBtn);
		
		JButton thongKeBtn = new JButton("Thong Ke", thongKeIcon);
		thongKeBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(panel == xePnl) {
					
				} else if(panel == khachHangPnl) {

				} else if(panel == nhanVienPnl) {
					
				} else {
					
				}
			}
		});
		thongKeBtn.setVerticalTextPosition(SwingConstants.BOTTOM);
		thongKeBtn.setHorizontalTextPosition(SwingConstants.CENTER);
		thongKeBtn.setFont(new Font("Avenir Next", Font.BOLD, 24));
		thongKeBtn.setBounds(868, 445, 150, 156);
		panel.add(thongKeBtn);
		
		JButton nhapFileBtn = new JButton("Nhap File", nhapFileIcon);
		nhapFileBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(panel == xePnl) {
					
				} else if(panel == khachHangPnl) {

				} else if(panel == nhanVienPnl) {
					
				} else {
					
				}
			}
		});
		nhapFileBtn.setVerticalTextPosition(SwingConstants.BOTTOM);
		nhapFileBtn.setHorizontalTextPosition(SwingConstants.CENTER);
		nhapFileBtn.setFont(new Font("Avenir Next", Font.BOLD, 24));
		nhapFileBtn.setBounds(1078, 445, 150, 156);
		panel.add(nhapFileBtn);
		
	}
	
	public void updateTable(String databaseTable, JTable table) throws Exception {
		xeDatabase.updateXeDatabaseTable();
		DefaultTableModel model = new DefaultTableModel();
		ResultSet rs = database.getData(databaseTable);
		//load column name
		ResultSetMetaData rsMD = rs.getMetaData();
		int colNumber = rsMD.getColumnCount();
		String[] arr = new String[colNumber];
		for(int i=0;i<colNumber;i++) {
			arr[i] = rsMD.getColumnName(i+1);
		}
		model.setColumnIdentifiers(arr);
		table.getTableHeader().setFont(new Font("Lucida Grande", Font.BOLD, 18));
		//load data from database to table
		while(rs.next()) {
			for(int i=0;i<colNumber;i++) {
				arr[i] = rs.getString(i+1);
			}
			model.addRow(arr);
		}
		table.setModel(model);
	}
	
	void setUpThueXePanel() throws Exception {
		updateThueXeTable();
		thueXeTable.setFont(new Font("Lucida Grande", Font.PLAIN, 17));
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(6, 6, 1251, 412);
		thueXePnl.add(scrollPane);
		scrollPane.setViewportView(thueXeTable);
		
		JButton themBtn = new JButton("Them", themIcon);
		themBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ThemThueXe window = new ThemThueXe(giaoDienChinh);
				window.frame.setVisible(true);
			}
		});
		themBtn.setVerticalTextPosition(SwingConstants.BOTTOM);
		themBtn.setHorizontalTextPosition(SwingConstants.CENTER);
		themBtn.setFont(new Font("Avenir Next", Font.BOLD, 24));
		themBtn.setBounds(32, 445, 130, 156);
		thueXePnl.add(themBtn);
		
		JButton suaBtn = new JButton("Sua", suaIcon);
		suaBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int row = thueXeTable.getSelectedRow();
				if (row < 0) {
					ChonMotHang window = new ChonMotHang();
					window.frame.setVisible(true);
				} else {
					String maThueXeCanSua = (String) thueXeTable.getValueAt(row, 0);
					SuaThueXe window = new SuaThueXe(giaoDienChinh, maThueXeCanSua);
					window.frame.setVisible(true);
				}
			}
		});
		suaBtn.setVerticalTextPosition(SwingConstants.BOTTOM);
		suaBtn.setHorizontalTextPosition(SwingConstants.CENTER);
		suaBtn.setFont(new Font("Avenir Next", Font.BOLD, 24));
		suaBtn.setBounds(172, 445, 130, 156);
		thueXePnl.add(suaBtn);
		
		JButton xoaBtn = new JButton("Xoa", xoaIcon);
		xoaBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int row = thueXeTable.getSelectedRow();
				if (row < 0) {
					ChonMotHang window = new ChonMotHang();
					window.frame.setVisible(true);
				} else {
					String maThueXeCanXoa = (String) thueXeTable.getValueAt(row, 0);
					XoaThueXe window = new XoaThueXe(giaoDienChinh, maThueXeCanXoa);
					window.frame.setVisible(true);
				}
			}
		});
		xoaBtn.setVerticalTextPosition(SwingConstants.BOTTOM);
		xoaBtn.setHorizontalTextPosition(SwingConstants.CENTER);
		xoaBtn.setFont(new Font("Avenir Next", Font.BOLD, 24));
		xoaBtn.setBounds(312, 445, 130, 156);
		thueXePnl.add(xoaBtn);
		
		JButton timKiemBtn = new JButton("Tim Kiem", timKiemIcon);
		timKiemBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		timKiemBtn.setVerticalTextPosition(SwingConstants.BOTTOM);
		timKiemBtn.setHorizontalTextPosition(SwingConstants.CENTER);
		timKiemBtn.setFont(new Font("Avenir Next", Font.BOLD, 24));
		timKiemBtn.setBounds(452, 445, 130, 156);
		thueXePnl.add(timKiemBtn);
		
		JButton thongKeBtn = new JButton("Thong Ke", thongKeIcon);
		thongKeBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		thongKeBtn.setVerticalTextPosition(SwingConstants.BOTTOM);
		thongKeBtn.setHorizontalTextPosition(SwingConstants.CENTER);
		thongKeBtn.setFont(new Font("Avenir Next", Font.BOLD, 24));
		thongKeBtn.setBounds(592, 445, 130, 156);
		thueXePnl.add(thongKeBtn);
		
		JButton inPhieuBtn = new JButton("In Phieu", inPhieuIcon);
		inPhieuBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		inPhieuBtn.setVerticalTextPosition(SwingConstants.BOTTOM);
		inPhieuBtn.setHorizontalTextPosition(SwingConstants.CENTER);
		inPhieuBtn.setFont(new Font("Avenir Next", Font.BOLD, 24));
		inPhieuBtn.setBounds(732, 445, 130, 156);
		thueXePnl.add(inPhieuBtn);
		
		JButton xemChiTietBtn = new JButton("Xem Chi Tiet", chiTietIcon);
		xemChiTietBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int row = thueXeTable.getSelectedRow();
				if (row < 0) {
					ChonMotHang window = new ChonMotHang();
					window.frame.setVisible(true);
				} else {
					String maThueXe = (String) thueXeTable.getValueAt(row, 0);
					XemChiTietThueXe window = new XemChiTietThueXe(giaoDienChinh, maThueXe);
					window.frame.setVisible(true);
				}
			}
		});
		xemChiTietBtn.setVerticalTextPosition(SwingConstants.BOTTOM);
		xemChiTietBtn.setHorizontalTextPosition(SwingConstants.CENTER);
		xemChiTietBtn.setFont(new Font("Avenir Next", Font.BOLD, 24));
		xemChiTietBtn.setBounds(872, 445, 175, 156);
		thueXePnl.add(xemChiTietBtn);
		
		JButton tienNhanLaiBtn = new JButton("Tien Nhan Lai", tienIcon);
		tienNhanLaiBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int row = thueXeTable.getSelectedRow();
				if (row < 0) {
					ChonMotHang window = new ChonMotHang();
					window.frame.setVisible(true);
				} else {
					String maThueXe = (String) thueXeTable.getValueAt(row, 0);
					TienNhanLai window = new TienNhanLai(giaoDienChinh, maThueXe);
					window.frame.setVisible(true);
				}
			}
		});
		tienNhanLaiBtn.setVerticalTextPosition(SwingConstants.BOTTOM);
		tienNhanLaiBtn.setHorizontalTextPosition(SwingConstants.CENTER);
		tienNhanLaiBtn.setFont(new Font("Avenir Next", Font.BOLD, 24));
		tienNhanLaiBtn.setBounds(1057, 445, 175, 156);
		thueXePnl.add(tienNhanLaiBtn);
		
	}
	
	public void updateThueXeTable() throws Exception {
		database.updateThueXeDatabaseTable();
		DefaultTableModel model = new DefaultTableModel();
		ResultSet rs = database.getData("ThueXe");
		//load column name
		ResultSetMetaData rsMD = rs.getMetaData();
		String[] arr = new String[10];
		arr[0] = rsMD.getColumnName(1);
		arr[1] = rsMD.getColumnName(2);
		arr[2] = "Ten Khach Hang";
		arr[3] = rsMD.getColumnName(3);
		arr[4] = "Ten Nhan Vien";
		arr[5] = rsMD.getColumnName(4);
		arr[6] = rsMD.getColumnName(5);
		arr[7] = rsMD.getColumnName(6);
		arr[8] = rsMD.getColumnName(7);
		arr[9] = rsMD.getColumnName(8);
		model.setColumnIdentifiers(arr);
		thueXeTable.getTableHeader().setFont(new Font("Lucida Grande", Font.BOLD, 18));
		//load data from database to table
		while(rs.next()) {
			arr[0] = rs.getString(1);
			String maKhachHang = rs.getString(2);
			arr[1] = maKhachHang;
			arr[2] = khachHangDatabase.getTenKhachHang(maKhachHang);
			String maNhanVien = rs.getString(3);
			arr[3] = maNhanVien;
			arr[4] = nhanVienDatabase.getTenNhanVien(maNhanVien);
			arr[5] = rs.getString(4);
			arr[6] = rs.getString(5);
			arr[7] = rs.getString(6);
			arr[8] = rs.getString(7);
			arr[9] = rs.getString(8);
			model.addRow(arr);
		}
		thueXeTable.setModel(model);
	}
	
	void setUpTaiKhoanPanel() throws Exception {
		
	}
	
	
	
}
