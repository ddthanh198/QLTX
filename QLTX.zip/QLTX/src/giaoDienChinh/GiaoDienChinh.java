package giaoDienChinh;

import java.awt.EventQueue;

import javax.swing.*;
import java.awt.Font;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import javax.swing.border.EtchedBorder;
import javax.swing.table.DefaultTableModel;

import chinhSuaThongTin.ChinhSuaThongTin;
import database.Database;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class GiaoDienChinh {
	Database database;
	JFrame frame;
	JPanel xePnl;
	JPanel khachHangPnl;
	JPanel nhanVienPnl;
	JPanel thueXePnl;
	JPanel taiKhoanPnl;
	
	JTable xeTable = new JTable();
	JTable khachHangTable = new JTable();
	JTable nhanVienTable = new JTable();
	JTable thueXeTable = new JTable();
	
	String iconFolderPath = ChinhSuaThongTin.iconFolderPath;
	ImageIcon themIcon = new ImageIcon(iconFolderPath + "them.png");
	ImageIcon suaIcon = new ImageIcon(iconFolderPath + "sua.png");
	ImageIcon xoaIcon = new ImageIcon(iconFolderPath + "xoa.png");
	ImageIcon nhapFileIcon = new ImageIcon(iconFolderPath + "nhapFile.png");
	ImageIcon timKiemIcon = new ImageIcon(iconFolderPath + "timKiem.png");
	ImageIcon thongKeIcon = new ImageIcon(iconFolderPath + "thongKe.png");
	ImageIcon inPhieuIcon = new ImageIcon(iconFolderPath + "inPhieu.png");
	ImageIcon tienIcon = new ImageIcon(iconFolderPath + "tien.png");
	ImageIcon chiTietIcon = new ImageIcon(iconFolderPath + "chiTiet.png");
	ImageIcon xeIcon = new ImageIcon(iconFolderPath + "xe.png");
	ImageIcon khachHangIcon = new ImageIcon(iconFolderPath + "khachHang.png");
	ImageIcon nhanVienIcon = new ImageIcon(iconFolderPath + "nhanVien.png");
	ImageIcon thueXeIcon = new ImageIcon(iconFolderPath + "thueXe.png");
	ImageIcon taiKhoanIcon = new ImageIcon(iconFolderPath + "taiKhoan.png");
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GiaoDienChinh window = new GiaoDienChinh();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public GiaoDienChinh() throws Exception {
		database = new Database();
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() throws Exception {
		frame = new JFrame();
		frame.setTitle("QUAN LY THUE XE");
		frame.setBounds(30, 30, 1380, 840);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		tabbedPane.setFont(new Font("Avenir Next", Font.BOLD, 24));
		tabbedPane.setBounds(6, 6, 1368, 806);
		frame.getContentPane().add(tabbedPane);
		
		xePnl = new JPanel();
		tabbedPane.addTab("Xe", xeIcon, xePnl, null);
		xePnl.setLayout(null);
		setUpPanel(xePnl, "Xe", xeTable);
		
		khachHangPnl = new JPanel();
		tabbedPane.addTab("Khach Hang", khachHangIcon, khachHangPnl, null);
		khachHangPnl.setLayout(null);
		setUpPanel(khachHangPnl, "KhachHang", khachHangTable);
		
		nhanVienPnl = new JPanel();
		tabbedPane.addTab("Nhan Vien", nhanVienIcon, nhanVienPnl, null);
		nhanVienPnl.setLayout(null);
		setUpPanel(nhanVienPnl, "NhanVien", nhanVienTable);
		
		thueXePnl = new JPanel();
		tabbedPane.addTab("Thue Xe", thueXeIcon, thueXePnl, null);
		thueXePnl.setLayout(null);
		setUpThueXePanel();
		
		taiKhoanPnl = new JPanel();
		tabbedPane.addTab("Tai Khoan", taiKhoanIcon, taiKhoanPnl, null);
		taiKhoanPnl.setLayout(null);
		setUpTaiKhoanPanel();
	}
	
	void setUpPanel(JPanel panel, String databaseTable, JTable table) throws Exception {
		updateTable(databaseTable, table);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(6, 6, 1331, 542);
		panel.add(scrollPane);
		scrollPane.setViewportView(table);
		table.setFont(new Font("Lucida Grande", Font.PLAIN, 17));
		
		JButton themBtn = new JButton("Them", themIcon);
		themBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(panel == xePnl) {
					
				} else if(panel == khachHangPnl) {
					
				} else if(panel == nhanVienPnl) {
					
				} else {
					
				}
			}
		});
		themBtn.setHorizontalTextPosition(JButton.CENTER);
		themBtn.setVerticalTextPosition(JButton.BOTTOM);
		themBtn.setFont(new Font("Avenir Next", Font.BOLD, 24));
		themBtn.setBounds(45, 577, 150, 156);
		panel.add(themBtn);
		
		JButton suaBtn = new JButton("Sua", suaIcon);
		suaBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(panel == xePnl) {
					
				} else if(panel == khachHangPnl) {

				} else if(panel == nhanVienPnl) {
					
				} else {
					
				}
			}
		});
		suaBtn.setVerticalTextPosition(SwingConstants.BOTTOM);
		suaBtn.setHorizontalTextPosition(SwingConstants.CENTER);
		suaBtn.setFont(new Font("Avenir Next", Font.BOLD, 24));
		suaBtn.setBounds(265, 577, 150, 156);
		panel.add(suaBtn);
		
		JButton xoaBtn = new JButton("Xoa", xoaIcon);
		xoaBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(panel == xePnl) {
					
				} else if(panel == khachHangPnl) {

				} else if(panel == nhanVienPnl) {
					
				} else {
					
				}
			}
		});
		xoaBtn.setVerticalTextPosition(SwingConstants.BOTTOM);
		xoaBtn.setHorizontalTextPosition(SwingConstants.CENTER);
		xoaBtn.setFont(new Font("Avenir Next", Font.BOLD, 24));
		xoaBtn.setBounds(485, 577, 150, 156);
		panel.add(xoaBtn);
		
		JButton nhapFileBtn = new JButton("Nhap File", nhapFileIcon);
		nhapFileBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(panel == xePnl) {
					
				} else if(panel == khachHangPnl) {

				} else if(panel == nhanVienPnl) {
					
				} else {
					
				}
			}
		});
		nhapFileBtn.setVerticalTextPosition(SwingConstants.BOTTOM);
		nhapFileBtn.setHorizontalTextPosition(SwingConstants.CENTER);
		nhapFileBtn.setFont(new Font("Avenir Next", Font.BOLD, 24));
		nhapFileBtn.setBounds(1145, 577, 150, 156);
		panel.add(nhapFileBtn);
		
		JButton timKiemBtn = new JButton("Tim Kiem", timKiemIcon);
		timKiemBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(panel == xePnl) {
					
				} else if(panel == khachHangPnl) {

				} else if(panel == nhanVienPnl) {
					
				} else {
					
				}
			}
		});
		timKiemBtn.setVerticalTextPosition(SwingConstants.BOTTOM);
		timKiemBtn.setHorizontalTextPosition(SwingConstants.CENTER);
		timKiemBtn.setFont(new Font("Avenir Next", Font.BOLD, 24));
		timKiemBtn.setBounds(705, 577, 150, 156);
		panel.add(timKiemBtn);
		
		JButton thongKeBtn = new JButton("Thong Ke", thongKeIcon);
		thongKeBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(panel == xePnl) {
					
				} else if(panel == khachHangPnl) {

				} else if(panel == nhanVienPnl) {
					
				} else {
					
				}
			}
		});
		thongKeBtn.setVerticalTextPosition(SwingConstants.BOTTOM);
		thongKeBtn.setHorizontalTextPosition(SwingConstants.CENTER);
		thongKeBtn.setFont(new Font("Avenir Next", Font.BOLD, 24));
		thongKeBtn.setBounds(925, 577, 150, 156);
		panel.add(thongKeBtn);
		
	}

	void setUpThueXePanel() throws Exception {
		updateTable("ThueXe", thueXeTable);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(6, 6, 1331, 542);
		thueXePnl.add(scrollPane);
		scrollPane.setViewportView(thueXeTable);
		thueXeTable.setFont(new Font("Lucida Grande", Font.PLAIN, 17));
		
		JButton themBtn = new JButton("Them", themIcon);
		themBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		themBtn.setVerticalTextPosition(SwingConstants.BOTTOM);
		themBtn.setHorizontalTextPosition(SwingConstants.CENTER);
		themBtn.setFont(new Font("Avenir Next", Font.BOLD, 24));
		themBtn.setBounds(45, 576, 130, 156);
		thueXePnl.add(themBtn);
		
		JButton suaBtn = new JButton("Sua", suaIcon);
		suaBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		suaBtn.setVerticalTextPosition(SwingConstants.BOTTOM);
		suaBtn.setHorizontalTextPosition(SwingConstants.CENTER);
		suaBtn.setFont(new Font("Avenir Next", Font.BOLD, 24));
		suaBtn.setBounds(187, 576, 130, 156);
		thueXePnl.add(suaBtn);
		
		JButton xoaBtn = new JButton("Xoa", xoaIcon);
		xoaBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		xoaBtn.setVerticalTextPosition(SwingConstants.BOTTOM);
		xoaBtn.setHorizontalTextPosition(SwingConstants.CENTER);
		xoaBtn.setFont(new Font("Avenir Next", Font.BOLD, 24));
		xoaBtn.setBounds(329, 576, 130, 156);
		thueXePnl.add(xoaBtn);
		
		JButton timKiemBtn = new JButton("Tim Kiem", timKiemIcon);
		timKiemBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		timKiemBtn.setVerticalTextPosition(SwingConstants.BOTTOM);
		timKiemBtn.setHorizontalTextPosition(SwingConstants.CENTER);
		timKiemBtn.setFont(new Font("Avenir Next", Font.BOLD, 24));
		timKiemBtn.setBounds(472, 576, 130, 156);
		thueXePnl.add(timKiemBtn);
		
		JButton thongKeBtn = new JButton("Thong Ke", thongKeIcon);
		thongKeBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		thongKeBtn.setVerticalTextPosition(SwingConstants.BOTTOM);
		thongKeBtn.setHorizontalTextPosition(SwingConstants.CENTER);
		thongKeBtn.setFont(new Font("Avenir Next", Font.BOLD, 24));
		thongKeBtn.setBounds(614, 576, 130, 156);
		thueXePnl.add(thongKeBtn);
		
		JButton inPhieuBtn = new JButton("In Phieu", inPhieuIcon);
		inPhieuBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		inPhieuBtn.setVerticalTextPosition(SwingConstants.BOTTOM);
		inPhieuBtn.setHorizontalTextPosition(SwingConstants.CENTER);
		inPhieuBtn.setFont(new Font("Avenir Next", Font.BOLD, 24));
		inPhieuBtn.setBounds(756, 576, 130, 156);
		thueXePnl.add(inPhieuBtn);
		
		JButton tienNhanLaiBtn = new JButton("Tien Nhan Lai", tienIcon);
		tienNhanLaiBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		tienNhanLaiBtn.setVerticalTextPosition(SwingConstants.BOTTOM);
		tienNhanLaiBtn.setHorizontalTextPosition(SwingConstants.CENTER);
		tienNhanLaiBtn.setFont(new Font("Avenir Next", Font.BOLD, 24));
		tienNhanLaiBtn.setBounds(1104, 576, 194, 156);
		thueXePnl.add(tienNhanLaiBtn);
		
		JButton xemChiTietBtn = new JButton("Xem Chi Tiet", chiTietIcon);
		xemChiTietBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		xemChiTietBtn.setVerticalTextPosition(SwingConstants.BOTTOM);
		xemChiTietBtn.setHorizontalTextPosition(SwingConstants.CENTER);
		xemChiTietBtn.setFont(new Font("Avenir Next", Font.BOLD, 24));
		xemChiTietBtn.setBounds(898, 576, 194, 156);
		thueXePnl.add(xemChiTietBtn);
	}
	
	void setUpTaiKhoanPanel() throws Exception {
		
	}
	
	void updateTable(String databaseTable, JTable table) throws Exception {
		DefaultTableModel model = new DefaultTableModel();
		ResultSet rs = database.getData(databaseTable);
		//load column name
		ResultSetMetaData rsMD = rs.getMetaData();
		int colNumber = rsMD.getColumnCount();
		String[] arr = new String[colNumber];
		for(int i=0;i<colNumber;i++) {
			arr[i] = rsMD.getColumnName(i+1);
		}
		model.setColumnIdentifiers(arr);
		table.getTableHeader().setFont(new Font("Lucida Grande", Font.BOLD, 18));
		//load data from database to table
		while(rs.next()) {
			for(int i=0;i<colNumber;i++) {
				arr[i] = rs.getString(i+1);
			}
			model.addRow(arr);
		}
		table.setModel(model);
	}
}
