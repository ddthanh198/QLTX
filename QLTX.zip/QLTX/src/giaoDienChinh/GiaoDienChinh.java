package giaoDienChinh;

import java.awt.EventQueue;

import javax.swing.*;
import java.awt.Font;
import java.awt.Window;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import javax.swing.border.EtchedBorder;
import javax.swing.table.DefaultTableModel;

import chinhSuaThongTin.ChinhSuaThongTin;
import database.*;
import khachHang.*;
import nhanVien.*;
import thongBao.ChonMotHang;
import xe.*;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class GiaoDienChinh {
	
	GiaoDienChinh giaoDienChinh = this;
	
	Database database;
	JFrame frame;
	JPanel xePnl;
	JPanel khachHangPnl;
	JPanel nhanVienPnl;
	JPanel thueXePnl;
	JPanel taiKhoanPnl;
	
	public JTable xeTable = new JTable();
	public JTable khachHangTable = new JTable();
	public JTable nhanVienTable = new JTable();
	public JTable thueXeTable = new JTable();
	
	String iconFolderPath = ChinhSuaThongTin.iconFolderPath;
	ImageIcon themIcon = new ImageIcon(iconFolderPath + "them.png");
	ImageIcon suaIcon = new ImageIcon(iconFolderPath + "sua.png");
	ImageIcon xoaIcon = new ImageIcon(iconFolderPath + "xoa.png");
	ImageIcon nhapFileIcon = new ImageIcon(iconFolderPath + "nhapFile.png");
	ImageIcon timKiemIcon = new ImageIcon(iconFolderPath + "timKiem.png");
	ImageIcon thongKeIcon = new ImageIcon(iconFolderPath + "thongKe.png");
	ImageIcon inPhieuIcon = new ImageIcon(iconFolderPath + "inPhieu.png");
	ImageIcon tienIcon = new ImageIcon(iconFolderPath + "tien.png");
	ImageIcon chiTietIcon = new ImageIcon(iconFolderPath + "chiTiet.png");
	ImageIcon xeIcon = new ImageIcon(iconFolderPath + "xe.png");
	ImageIcon khachHangIcon = new ImageIcon(iconFolderPath + "khachHang.png");
	ImageIcon nhanVienIcon = new ImageIcon(iconFolderPath + "nhanVien.png");
	ImageIcon thueXeIcon = new ImageIcon(iconFolderPath + "thueXe.png");
	ImageIcon taiKhoanIcon = new ImageIcon(iconFolderPath + "taiKhoan.png");
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GiaoDienChinh window = new GiaoDienChinh();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public GiaoDienChinh() throws Exception {
		database = new Database();
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() throws Exception {
		frame = new JFrame();
		frame.setTitle("QUAN LY THUE XE");
		frame.setBounds(30, 30, 1300, 700);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		tabbedPane.setFont(new Font("Avenir Next", Font.BOLD, 24));
		tabbedPane.setBounds(6, 6, 1288, 666);
		frame.getContentPane().add(tabbedPane);
		
		xePnl = new JPanel();
		tabbedPane.addTab("Xe", xeIcon, xePnl, null);
		xePnl.setLayout(null);
		setUpPanel(xePnl, "Xe", xeTable);
		
		khachHangPnl = new JPanel();
		tabbedPane.addTab("Khach Hang", khachHangIcon, khachHangPnl, null);
		khachHangPnl.setLayout(null);
		setUpPanel(khachHangPnl, "KhachHang", khachHangTable);
		
		nhanVienPnl = new JPanel();
		tabbedPane.addTab("Nhan Vien", nhanVienIcon, nhanVienPnl, null);
		nhanVienPnl.setLayout(null);
		setUpPanel(nhanVienPnl, "NhanVien", nhanVienTable);
		
		thueXePnl = new JPanel();
		tabbedPane.addTab("Thue Xe", thueXeIcon, thueXePnl, null);
		thueXePnl.setLayout(null);
		setUpThueXePanel();
		
		taiKhoanPnl = new JPanel();
		tabbedPane.addTab("Tai Khoan", taiKhoanIcon, taiKhoanPnl, null);
		taiKhoanPnl.setLayout(null);
		setUpTaiKhoanPanel();
	}
	
	void setUpPanel(JPanel panel, String databaseTable, JTable table) throws Exception {
		updateTable(databaseTable, table);
		table.setFont(new Font("Lucida Grande", Font.PLAIN, 17));
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(6, 6, 1251, 412);
		panel.add(scrollPane);
		scrollPane.setViewportView(table);
		
		JButton themBtn = new JButton("Them", themIcon);
		themBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(panel == xePnl) {
					ThemXe window = new ThemXe(giaoDienChinh);
					window.frame.setVisible(true);
				} else if(panel == khachHangPnl) {
					ThemKhachHang window = new ThemKhachHang(giaoDienChinh);
					window.frame.setVisible(true);
				} else if(panel == nhanVienPnl) {
					ThemNhanVien window = new ThemNhanVien(giaoDienChinh);
					window.frame.setVisible(true);
				} 
			}
		});
		themBtn.setHorizontalTextPosition(JButton.CENTER);
		themBtn.setVerticalTextPosition(JButton.BOTTOM);
		themBtn.setFont(new Font("Avenir Next", Font.BOLD, 24));
		themBtn.setBounds(28, 445, 150, 156);
		panel.add(themBtn);
		
		JButton suaBtn = new JButton("Sua", suaIcon);
		suaBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(panel == xePnl) {
					int row = xeTable.getSelectedRow();
					if (row < 0) {
						ChonMotHang window = new ChonMotHang();
						window.frame.setVisible(true);
					} else {
						String maXeCanSua = (String) xeTable.getValueAt(row, 0);
						SuaXe window = new SuaXe(giaoDienChinh, maXeCanSua);
						window.frame.setVisible(true);
					}
				} else if(panel == khachHangPnl) {
					int row = khachHangTable.getSelectedRow();
					if (row < 0) {
						ChonMotHang window = new ChonMotHang();
						window.frame.setVisible(true);
					} else {
						String maKhachHangCanSua = (String) khachHangTable.getValueAt(row, 0);
						SuaKhachHang window = new SuaKhachHang(giaoDienChinh, maKhachHangCanSua);
						window.frame.setVisible(true);
					}
				} else if(panel == nhanVienPnl) {
					int row = nhanVienTable.getSelectedRow();
					if (row < 0) {
						ChonMotHang window = new ChonMotHang();
						window.frame.setVisible(true);
					} else {
						String maNhanVienCanSua = (String) nhanVienTable.getValueAt(row, 0);
						SuaNhanVien window = new SuaNhanVien(giaoDienChinh, maNhanVienCanSua);
						window.frame.setVisible(true);
					}
				} 
			}
		});
		suaBtn.setVerticalTextPosition(SwingConstants.BOTTOM);
		suaBtn.setHorizontalTextPosition(SwingConstants.CENTER);
		suaBtn.setFont(new Font("Avenir Next", Font.BOLD, 24));
		suaBtn.setBounds(238, 445, 150, 156);
		panel.add(suaBtn);
		
		JButton xoaBtn = new JButton("Xoa", xoaIcon);
		xoaBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(panel == xePnl) {
					int row = xeTable.getSelectedRow();
					if (row < 0) {
						ChonMotHang window = new ChonMotHang();
						window.frame.setVisible(true);
					} else {
						String maXeCanXoa = (String) xeTable.getValueAt(row, 0);
						XoaXe window = new XoaXe(giaoDienChinh, maXeCanXoa);
						window.frame.setVisible(true);
					}
				} else if(panel == khachHangPnl) {
					int row = khachHangTable.getSelectedRow();
					if (row < 0) {
						ChonMotHang window = new ChonMotHang();
						window.frame.setVisible(true);
					} else {
						String maKhachHangCanXoa = (String) khachHangTable.getValueAt(row, 0);
						XoaKhachHang window = new XoaKhachHang(giaoDienChinh, maKhachHangCanXoa);
						window.frame.setVisible(true);
					}
				} else if(panel == nhanVienPnl) {
					int row = nhanVienTable.getSelectedRow();
					if (row < 0) {
						ChonMotHang window = new ChonMotHang();
						window.frame.setVisible(true);
					} else {
						String maNhanVienCanXoa = (String) nhanVienTable.getValueAt(row, 0);
						XoaNhanVien window = new XoaNhanVien(giaoDienChinh, maNhanVienCanXoa);
						window.frame.setVisible(true);
					}
				} 
			}
		});
		xoaBtn.setVerticalTextPosition(SwingConstants.BOTTOM);
		xoaBtn.setHorizontalTextPosition(SwingConstants.CENTER);
		xoaBtn.setFont(new Font("Avenir Next", Font.BOLD, 24));
		xoaBtn.setBounds(448, 445, 150, 156);
		panel.add(xoaBtn);
		
		JButton timKiemBtn = new JButton("Tim Kiem", timKiemIcon);
		timKiemBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(panel == xePnl) {
					
				} else if(panel == khachHangPnl) {

				} else if(panel == nhanVienPnl) {
					
				} else {
					
				}
			}
		});
		timKiemBtn.setVerticalTextPosition(SwingConstants.BOTTOM);
		timKiemBtn.setHorizontalTextPosition(SwingConstants.CENTER);
		timKiemBtn.setFont(new Font("Avenir Next", Font.BOLD, 24));
		timKiemBtn.setBounds(658, 445, 150, 156);
		panel.add(timKiemBtn);
		
		JButton thongKeBtn = new JButton("Thong Ke", thongKeIcon);
		thongKeBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(panel == xePnl) {
					
				} else if(panel == khachHangPnl) {

				} else if(panel == nhanVienPnl) {
					
				} else {
					
				}
			}
		});
		thongKeBtn.setVerticalTextPosition(SwingConstants.BOTTOM);
		thongKeBtn.setHorizontalTextPosition(SwingConstants.CENTER);
		thongKeBtn.setFont(new Font("Avenir Next", Font.BOLD, 24));
		thongKeBtn.setBounds(868, 445, 150, 156);
		panel.add(thongKeBtn);
		
		JButton nhapFileBtn = new JButton("Nhap File", nhapFileIcon);
		nhapFileBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(panel == xePnl) {
					
				} else if(panel == khachHangPnl) {

				} else if(panel == nhanVienPnl) {
					
				} else {
					
				}
			}
		});
		nhapFileBtn.setVerticalTextPosition(SwingConstants.BOTTOM);
		nhapFileBtn.setHorizontalTextPosition(SwingConstants.CENTER);
		nhapFileBtn.setFont(new Font("Avenir Next", Font.BOLD, 24));
		nhapFileBtn.setBounds(1078, 445, 150, 156);
		panel.add(nhapFileBtn);
		
	}

	void setUpThueXePanel() throws Exception {
		updateTable("ThueXe", thueXeTable);
		thueXeTable.setFont(new Font("Lucida Grande", Font.PLAIN, 17));
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(6, 6, 1251, 412);
		thueXePnl.add(scrollPane);
		scrollPane.setViewportView(thueXeTable);
		
		JButton themBtn = new JButton("Them", themIcon);
		themBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		themBtn.setVerticalTextPosition(SwingConstants.BOTTOM);
		themBtn.setHorizontalTextPosition(SwingConstants.CENTER);
		themBtn.setFont(new Font("Avenir Next", Font.BOLD, 24));
		themBtn.setBounds(32, 445, 130, 156);
		thueXePnl.add(themBtn);
		
		JButton suaBtn = new JButton("Sua", suaIcon);
		suaBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		suaBtn.setVerticalTextPosition(SwingConstants.BOTTOM);
		suaBtn.setHorizontalTextPosition(SwingConstants.CENTER);
		suaBtn.setFont(new Font("Avenir Next", Font.BOLD, 24));
		suaBtn.setBounds(172, 445, 130, 156);
		thueXePnl.add(suaBtn);
		
		JButton xoaBtn = new JButton("Xoa", xoaIcon);
		xoaBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		xoaBtn.setVerticalTextPosition(SwingConstants.BOTTOM);
		xoaBtn.setHorizontalTextPosition(SwingConstants.CENTER);
		xoaBtn.setFont(new Font("Avenir Next", Font.BOLD, 24));
		xoaBtn.setBounds(312, 445, 130, 156);
		thueXePnl.add(xoaBtn);
		
		JButton timKiemBtn = new JButton("Tim Kiem", timKiemIcon);
		timKiemBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		timKiemBtn.setVerticalTextPosition(SwingConstants.BOTTOM);
		timKiemBtn.setHorizontalTextPosition(SwingConstants.CENTER);
		timKiemBtn.setFont(new Font("Avenir Next", Font.BOLD, 24));
		timKiemBtn.setBounds(452, 445, 130, 156);
		thueXePnl.add(timKiemBtn);
		
		JButton thongKeBtn = new JButton("Thong Ke", thongKeIcon);
		thongKeBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		thongKeBtn.setVerticalTextPosition(SwingConstants.BOTTOM);
		thongKeBtn.setHorizontalTextPosition(SwingConstants.CENTER);
		thongKeBtn.setFont(new Font("Avenir Next", Font.BOLD, 24));
		thongKeBtn.setBounds(592, 445, 130, 156);
		thueXePnl.add(thongKeBtn);
		
		JButton inPhieuBtn = new JButton("In Phieu", inPhieuIcon);
		inPhieuBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		inPhieuBtn.setVerticalTextPosition(SwingConstants.BOTTOM);
		inPhieuBtn.setHorizontalTextPosition(SwingConstants.CENTER);
		inPhieuBtn.setFont(new Font("Avenir Next", Font.BOLD, 24));
		inPhieuBtn.setBounds(732, 445, 130, 156);
		thueXePnl.add(inPhieuBtn);
		
		JButton xemChiTietBtn = new JButton("Xem Chi Tiet", chiTietIcon);
		xemChiTietBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		xemChiTietBtn.setVerticalTextPosition(SwingConstants.BOTTOM);
		xemChiTietBtn.setHorizontalTextPosition(SwingConstants.CENTER);
		xemChiTietBtn.setFont(new Font("Avenir Next", Font.BOLD, 24));
		xemChiTietBtn.setBounds(872, 445, 175, 156);
		thueXePnl.add(xemChiTietBtn);
		
		JButton tienNhanLaiBtn = new JButton("Tien Nhan Lai", tienIcon);
		tienNhanLaiBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		tienNhanLaiBtn.setVerticalTextPosition(SwingConstants.BOTTOM);
		tienNhanLaiBtn.setHorizontalTextPosition(SwingConstants.CENTER);
		tienNhanLaiBtn.setFont(new Font("Avenir Next", Font.BOLD, 24));
		tienNhanLaiBtn.setBounds(1057, 445, 175, 156);
		thueXePnl.add(tienNhanLaiBtn);
		
	}
	
	void setUpTaiKhoanPanel() throws Exception {
		
	}
	
	public void updateTable(String databaseTable, JTable table) throws Exception {
		DefaultTableModel model = new DefaultTableModel();
		ResultSet rs = database.getData(databaseTable);
		//load column name
		ResultSetMetaData rsMD = rs.getMetaData();
		int colNumber = rsMD.getColumnCount();
		String[] arr = new String[colNumber];
		for(int i=0;i<colNumber;i++) {
			arr[i] = rsMD.getColumnName(i+1);
		}
		model.setColumnIdentifiers(arr);
		table.getTableHeader().setFont(new Font("Lucida Grande", Font.BOLD, 18));
		//load data from database to table
		while(rs.next()) {
			for(int i=0;i<colNumber;i++) {
				arr[i] = rs.getString(i+1);
			}
			model.addRow(arr);
		}
		table.setModel(model);
	}
}
