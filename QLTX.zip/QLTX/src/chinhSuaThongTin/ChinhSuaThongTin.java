package chinhSuaThongTin;

public class ChinhSuaThongTin {
	public static String driver = "com.mysql.jdbc.Driver";
	public static String url = "jdbc:mysql://127.0.0.1:3306/QL_CongTyChoThueXe?autoReconnect=true&useSSL=false";
	public static String user = "root";
	public static String password = "fabulous";
	
	public static String iconFolderPath = "/Users/macintosh/Desktop/eclipse workspace/QLTX/iconImages/";
}
