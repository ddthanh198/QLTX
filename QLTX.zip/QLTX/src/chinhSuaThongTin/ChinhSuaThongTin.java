package chinhSuaThongTin;

public class ChinhSuaThongTin {
	public static String driver = "com.mysql.jdbc.Driver";
	public static String url = "jdbc:mysql://127.0.0.1:3306/QL_CongTyChoThueXe?autoReconnect=true&useSSL=false";
	public static String user = "root";
	public static String password = "fabulous";
	
	public static String iconFolderPath = "/Users/macintosh/Desktop/eclipse workspace/QLTX/iconImages/";
	
	// tien coc de thue 1 xe la 1.000.000 vnd
	public static long donGiaCoc = 1000000;
	// tien phat tra muon 1 ngay la 200.000 vnd
	public static long donGiaPhat = 200000;
	
}
