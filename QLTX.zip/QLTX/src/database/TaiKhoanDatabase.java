package database;

import java.sql.Connection;
import java.sql.DriverManager;

import com.mysql.jdbc.PreparedStatement;

import chinhSuaThongTin.ChinhSuaThongTin;
import taiKhoan.TaiKhoan;

public class TaiKhoanDatabase {
	public String driver = ChinhSuaThongTin.driver;
	public String url = ChinhSuaThongTin.url;
	public String user = ChinhSuaThongTin.user;
	public String password = ChinhSuaThongTin.password;
	
	Connection connection;
	Database database;
	
	public TaiKhoanDatabase() {
		try {
//			Class.forName(driver);
//			connection = (Connection) DriverManager.getConnection(url, user, password);
			database = new Database();
			this.connection = database.connection;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void themTaiKhoan(TaiKhoan taiKhoan) throws Exception {
		String command = "INSERT INTO TaiKhoan (TaiKhoan, MatKhau, HoTen, NamSinh, DienThoai) " + "VALUES(?, ?, ?, ?, ?)";
		PreparedStatement statement = (PreparedStatement) connection.prepareStatement(command);
		statement.setString(1, taiKhoan.getTaiKhoan());
		statement.setString(2, taiKhoan.getMatKhau());
		statement.setString(3, taiKhoan.getHoTen());
		statement.setString(4, taiKhoan.getNamSinh());
		statement.setString(5, taiKhoan.getDienThoai());
		statement.executeUpdate();
	}
	
	public void suaTaiKhoan(TaiKhoan taiKhoan, String taiKhoanCanSua) throws Exception {
		String command = "UPDATE TaiKhoan SET HoTen = ?, NamSinh = ?, DienThoai = ? WHERE TaiKhoan = ?";
		PreparedStatement statement = (PreparedStatement) connection.prepareStatement(command);
		statement.setString(1, taiKhoan.getHoTen());
		statement.setString(2, taiKhoan.getNamSinh());
		statement.setString(3, taiKhoan.getDienThoai());
		statement.setString(4, taiKhoanCanSua);
		statement.executeUpdate();
	}
	
	public void doiMatKhau(String taiKhoan, String matKhauMoi) throws Exception {
		String command = "UPDATE TaiKhoan SET MatKhau = ? WHERE TaiKhoan = ?";
		PreparedStatement statement = (PreparedStatement) connection.prepareStatement(command);
		statement.setString(1, matKhauMoi);
		statement.setString(2, taiKhoan);
		statement.executeUpdate();
	}
}
