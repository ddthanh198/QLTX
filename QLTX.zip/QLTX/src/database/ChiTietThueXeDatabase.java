package database;

import java.sql.Connection;
import java.sql.DriverManager;

import com.mysql.jdbc.PreparedStatement;

import chiTietThueXe.ChiTietThueXe;
import chinhSuaThongTin.ChinhSuaThongTin;

public class ChiTietThueXeDatabase {
	public String driver = ChinhSuaThongTin.driver;
	public String url = ChinhSuaThongTin.url;
	public String user = ChinhSuaThongTin.user;
	public String password = ChinhSuaThongTin.password;
	
	Connection connection;
	
	public ChiTietThueXeDatabase() {
		try {
			Class.forName(driver);
			this.connection = (Connection) DriverManager.getConnection(url, user, password);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void themCTTX(ChiTietThueXe cttx) throws Exception {
		String  command = "INSERT INTO ChiTietThueXe (MaThueXe, MaXe, TienThue, TienPhat, GhiChu)" + "VALUES(?, ?, ?, ?, ?)";
		PreparedStatement statement = (PreparedStatement) connection.prepareStatement(command);
		statement.setString(1, cttx.getMaThueXe());
		statement.setString(2, cttx.getMaXe());
		statement.setString(3, String.valueOf(cttx.getTienThue()));
		statement.setString(4, String.valueOf(cttx.getTienPhat()));
		statement.setString(5, cttx.getGhiChu());
		statement.executeUpdate();
	}
	
	public void suaCTTX(ChiTietThueXe cttx, String maThueXeCanSua, String maXeCanSua) throws Exception {
		String command = "UPDATE ChiTietThueXe SET MaXe = ?, NgayTra= ?, TienThue = ?, TienPhat = ?, GhiChu = ? where MaThueXe = ? and MaXe = ?";
		PreparedStatement statement = (PreparedStatement) connection.prepareStatement(command);
		statement.setString(1, cttx.getMaXe());
		statement.setString(2, cttx.getNgayTra().getDateString());
		statement.setString(3, String.valueOf(cttx.getTienThue()));
		statement.setString(4, String.valueOf(cttx.getTienPhat()));		
		statement.setString(5, cttx.getGhiChu());
		statement.setString(6, maThueXeCanSua);
		statement.setString(7, maXeCanSua);
		statement.executeUpdate();
	}
	
	public void xoaCTTX(String maThueXe, String maXe) throws Exception {
		String command = "DELETE FROM ChiTietThueXe  WHERE MaThueXe = ? AND MaXe = ?";
		PreparedStatement statement = (PreparedStatement) connection.prepareStatement(command);
		statement.setString(1, maThueXe);
		statement.setString(2, maXe);
		statement.executeUpdate();
	}
}
