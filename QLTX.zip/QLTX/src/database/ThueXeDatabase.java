package database;

import java.sql.Connection;
import java.sql.DriverManager;

import com.mysql.jdbc.PreparedStatement;

import chinhSuaThongTin.ChinhSuaThongTin;
import thueXe.ThueXe;

public class ThueXeDatabase {
	public String driver = ChinhSuaThongTin.driver;
	public String url = ChinhSuaThongTin.url;
	public String user = ChinhSuaThongTin.user;
	public String password = ChinhSuaThongTin.password;
	
	Connection connection;
	
	public ThueXeDatabase() {
		try {
			Class.forName(driver);
			this.connection = (Connection) DriverManager.getConnection(url, user, password);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void themThueXe(ThueXe thueXe) throws Exception {
		String command = "INSERT INTO ThueXe (MaThueXe, MaKhachHang, MaNhanVien, NgayThue, NgayHenTra, TienCoc, ThanhTien, TongTienPhat)" + "VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
		PreparedStatement statement = (PreparedStatement) connection.prepareStatement(command);
		statement.setString(1, thueXe.getMaThueXe());
		statement.setString(2, thueXe.getMaKhachHang());
		statement.setString(3, thueXe.getMaNhanVien());
		statement.setString(4, thueXe.getNgayThue().getDateString());
		statement.setString(5, thueXe.getNgayHenTra().getDateString());
		statement.setString(6, String.valueOf(thueXe.getTienCoc()));
		statement.setString(7, String.valueOf(thueXe.getThanhTien()));
		statement.setString(8, String.valueOf(thueXe.getTongTienPhat()));
		statement.executeUpdate();
	}
	
	public void suaThueXe(ThueXe thueXe, String maThueXeCanSua) throws Exception {
		String command = "UPDATE ThueXe SET MaThueXe = ?, MaKhachHang  = ?, MaNhanVien = ?, NgayThue = ?, NgayHenTra = ?, TienCoc = ?, ThanhTien = ?, TongTienPhat = ? where MaThueXe = ?";
		PreparedStatement statement = (PreparedStatement) connection.prepareStatement(command);
		statement.setString(1, thueXe.getMaThueXe());
		statement.setString(2, thueXe.getMaKhachHang());
		statement.setString(3, thueXe.getMaNhanVien());
		statement.setString(4, thueXe.getNgayThue().getDateString());
		statement.setString(5, thueXe.getNgayHenTra().getDateString());
		statement.setString(6, String.valueOf(thueXe.getTienCoc()));
		statement.setString(7, String.valueOf(thueXe.getThanhTien()));
		statement.setString(8, String.valueOf(thueXe.getTongTienPhat()));
		statement.setString(9, maThueXeCanSua);
		statement.executeUpdate();
	}
	
	public void xoaThueXe(String maThueXe) throws Exception {
		String command = "DELETE FROM ThueXe WHERE MaThueXe = '" + maThueXe + "'";
		connection.prepareStatement(command).executeUpdate();
		command = "DELETE FROM ChiTietThueXe WHERE MaThueXe = '" + maThueXe + "'";
		connection.prepareStatement(command).executeUpdate();
	}
}
