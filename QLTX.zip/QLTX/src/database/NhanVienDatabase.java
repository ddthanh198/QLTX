package database;

import java.sql.Connection;
import java.sql.DriverManager;

import com.mysql.jdbc.PreparedStatement;

import chinhSuaThongTin.ChinhSuaThongTin;
import nhanVien.NhanVien;

public class NhanVienDatabase {
	public String driver = ChinhSuaThongTin.driver;
	public String url = ChinhSuaThongTin.url;
	public String user = ChinhSuaThongTin.user;
	public String password = ChinhSuaThongTin.password;
	
	Connection connection;
	
	public NhanVienDatabase() {
		try {
			Class.forName(driver);
			this.connection = (Connection) DriverManager.getConnection(url, user, password);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void themNhanVien(NhanVien nhanVien) throws Exception {
		String command = "INSERT INTO NhanVien (MaNhanVien, TenNhanVien, GioiTinh, NamSinh, ViTri, DT, Email, DiaChi)" + "VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
		PreparedStatement statement = (PreparedStatement) connection.prepareStatement(command);
		statement.setString(1, nhanVien.getMaNhanVien());
		statement.setString(2, nhanVien.getTenNhanVien());
		statement.setString(3, nhanVien.getGioiTinh());
		statement.setInt(4, nhanVien.getNamSinh());
		statement.setString(5, nhanVien.getViTri());
		statement.setString(6, nhanVien.getDT());
		statement.setString(7, nhanVien.getEmail());
		statement.setString(8, nhanVien.getDiaChi());
		statement.executeUpdate();
	}
	
	public void suaNhanVien(NhanVien nhanVien, String maNhanVienCanSua) throws Exception {
		String command = "UPDATE NhanVien SET MaNhanVien = ?, TenNhanVien  = ?, GioiTinh = ?, NamSinh = ?, ViTri = ?, DT = ?, Email = ?, DiaChi = ? where MaNhanVien = ?";
		PreparedStatement statement = (PreparedStatement) connection.prepareStatement(command);
		statement.setString(1, nhanVien.getMaNhanVien());
		statement.setString(2, nhanVien.getTenNhanVien());
		statement.setString(3, nhanVien.getGioiTinh());
		statement.setInt(4, nhanVien.getNamSinh());
		statement.setString(5, nhanVien.getViTri());
		statement.setString(6, nhanVien.getDT());
		statement.setString(7, nhanVien.getEmail());
		statement.setString(8, nhanVien.getDiaChi());
		statement.setString(9, maNhanVienCanSua);
		statement.executeUpdate();
	}
	
	public void xoaNhanVien(String maNhanVien) throws Exception {
		String command = "DELETE FROM NhanVien WHERE MaNhanVien = '" + maNhanVien + "'";
		connection.prepareStatement(command).executeUpdate();
		command = "DELETE FROM ThueXe WHERE MaNhanVien = '" + maNhanVien + "'";
		connection.prepareStatement(command).executeUpdate();
	}
}
