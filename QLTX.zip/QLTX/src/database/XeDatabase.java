package database;

import java.sql.Connection;
import java.sql.DriverManager;

import com.mysql.jdbc.PreparedStatement;

import chinhSuaThongTin.ChinhSuaThongTin;
import xe.Xe;

public class XeDatabase {
	public String driver = ChinhSuaThongTin.driver;
	public String url = ChinhSuaThongTin.url;
	public String user = ChinhSuaThongTin.user;
	public String password = ChinhSuaThongTin.password;
	
	Connection connection;
	
	public XeDatabase() {
		try {
			Class.forName(driver);
			this.connection = (Connection) DriverManager.getConnection(url, user, password);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void themXe(Xe xe) throws Exception {
		String command = "INSERT INTO Xe (MaXe, TenXe, LoaiXe, NamSanXuat, NgayNhap, TinhTrangXe, DonGiaThue, TrangThai) " + "VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
		PreparedStatement statement = (PreparedStatement) connection.prepareStatement(command);
		statement.setString(1, xe.getMaXe());
		statement.setString(2, xe.getTenXe());
		statement.setString(3, xe.getLoaiXe());
		statement.setInt(4, xe.getNamSanXuat());
		statement.setString(5, xe.getNgayNhap().getDateString());
		statement.setString(6, xe.getTinhTrangXe());
		statement.setString(7, String.valueOf(xe.getDonGiaThue()));
		statement.setString(8, xe.getTrangThai());
		statement.executeUpdate();
	}
	
	public void suaXe(Xe xe, String maXeCanSua) throws Exception {
		String command = "UPDATE Xe SET MaXe = ?, TenXe = ?, LoaiXe = ?, NamSanXuat = ?, NgayNhap = ?, TinhTrangXe = ?, DonGiaThue = ?, TrangThai = ? WHERE MaXe = ?";
		PreparedStatement statement = (PreparedStatement) connection.prepareStatement(command);
		statement.setString(1, xe.getMaXe());
		statement.setString(2, xe.getTenXe());
		statement.setString(3, xe.getLoaiXe());
		statement.setInt(4, xe.getNamSanXuat());
		statement.setString(5, xe.getNgayNhap().getDateString());
		statement.setString(6, xe.getTinhTrangXe());
		statement.setString(7, String.valueOf(xe.getDonGiaThue()));
		statement.setString(8, xe.getTrangThai());
		statement.setString(9, maXeCanSua);
		statement.executeUpdate();
	}
	
	public void xoaXe(String maXe) throws Exception {
		String command = "DELETE FROM Xe WHERE MaXe = '" + maXe + "'";
		connection.prepareStatement(command).executeUpdate();
		command = "DELETE FROM ChiTietThueXe WHERE MaXe = '" + maXe + "'";
		connection.prepareStatement(command).executeUpdate();
	}
	
}