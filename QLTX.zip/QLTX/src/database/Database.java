package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import chinhSuaThongTin.ChinhSuaThongTin;

public class Database {
	public String driver = ChinhSuaThongTin.driver;
	public String url = ChinhSuaThongTin.url;
	public String user = ChinhSuaThongTin.user;
	public String password = ChinhSuaThongTin.password;
	
	Connection connection;
	
	public Database() {
		try {
			Class.forName(driver);
			this.connection = (Connection) DriverManager.getConnection(url, user, password);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public ResultSet getData(String tableName) throws ClassNotFoundException, SQLException {
		String command = "SELECT * FROM " + tableName;
		return connection.prepareStatement(command).executeQuery();
	}
	
	public ResultSet getDataWithCondition(String tableName, String conditionalColumn, String conditionalValue) throws ClassNotFoundException, SQLException {
		String command = "SELECT * FROM " + tableName + " WHERE " + conditionalColumn + " LIKE '%" + conditionalValue + "%'";
		return connection.prepareStatement(command).executeQuery();
	}
	
	public ResultSet getDataWithExactCondition(String tableName, String conditionalColumn, String conditionalValue) throws ClassNotFoundException, SQLException {
		String command = "SELECT * FROM " + tableName + " WHERE " + conditionalColumn + " = '" + conditionalValue + "'";
		return connection.prepareStatement(command).executeQuery();
	}
	
}